const outputElement = document.getElementById("qr-momo");
const smallScreen = window.matchMedia("(max-width: 768px)");
function handleScreenChange(e) {
  if (e.matches) {
    outputElement.innerHTML = `
    <div class="qrWrapper" id="qr-momo">
        <div class="subtitle">
            <h3>
                Nhấn vào nút <b>Mở App MoMo</b> để chuyển đến trang thanh toán</h3>
        </div>
        <div class="qr-code-momo" >
                <button class="nhanTienBtn" href="https://nhantien.momo.vn">Mở App Momo</button>
        </div>
    </div>
    `;
  } else {
    outputElement.innerHTML = `
    <div class="qrWrapper" id="qr-momo">
                  <div class="subtitle">
                    <h3>
                      Sử dụng <b>App MoMo</b> hoặc ứng dụng camera hỗ trợ QR
                      code để quét mã
                    </h3>
                  </div>
                  <div class="qr-code-momo" >
                    <img
                      alt="paymentcode"
                      class="image-qr-code-momo"
                      src="https://chart.googleapis.com/chart?chs=350x350&cht=qr&chl=2|99|0982933507|NGUYEN%20TRONG%20VY|info@web2m.com|0|0|1000000||transfer_myqr"
                    />
                  </div>
                </div>
    `;
  }
}
smallScreen.addListener(handleScreenChange);
handleScreenChange(smallScreen);
